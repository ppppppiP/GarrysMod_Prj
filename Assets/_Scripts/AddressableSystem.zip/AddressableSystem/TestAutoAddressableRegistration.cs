﻿#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEditor.AddressableAssets;


public static class AutoAddressableProcessor
{
    [MenuItem("Tools/Process AutoAddressable Data + Register")]
    public static void ProcessAndRegister()
    {
        // Находим все объекты в открытых сценах с компонентом AutoAddressable, включая неактивные
        AutoAddressable[] autoObjs = GameObject.FindObjectsOfType<AutoAddressable>(true);

        // 1. Сначала заполняем данные для всех типов ассетов
        int countMesh = 0;
        int countAudio = 0;
        int countTexture = 0;
        foreach (var obj in autoObjs)
        {
            if (obj.processTexture)
            {
                AutoAddressableUtils.ExecuteWithActive(obj, (comp) => { comp.ProcessTextureData(); });
                countTexture++;
            }
        }
        Debug.Log($"[AutoAddressableProcessor] Обработано {countMesh} объектов для мешей, {countAudio} для звуков и {countTexture} для текстур.");

        // 2. Теперь регистрируем ассеты в Addressables (вызываем наши модули)
        var settings = AddressableAssetSettingsDefaultObject.Settings;
        if (settings == null)
        {
            Debug.LogError("AddressableAssetSettings не найдены!");
            return;
        }

        IAddressableModule[] modules = new IAddressableModule[]
        {
            new MeshAddressableModule(),
            new AudioAddressableModule(),
            new TextureAddressableModule()
        };

        int countRegister = 0;
        foreach (var autoObj in autoObjs)
        {
            // Если объект не активен, временно включаем его для регистрации
            AutoAddressableUtils.ExecuteWithActive(autoObj, (comp) =>
            {
                foreach (var module in modules)
                {
                    module.Process(comp.gameObject, settings);
                }
            });
            countRegister++;
        }
        Debug.Log($"[AutoAddressableProcessor] Обработано {countRegister} объектов для регистрации в Addressables.");

        // 3. Сохраняем изменения
        EditorUtility.SetDirty(settings);
        AssetDatabase.SaveAssets();
        Debug.Log("[AutoAddressableProcessor] Регистрация Addressable ассетов завершена.");

        foreach (var obj in autoObjs)
        {
            if (obj.processMesh)
            {
                AutoAddressableUtils.ExecuteWithActive(obj, (comp) => { comp.ProcessMeshData(); });
                countMesh++;
            }
            if (obj.processAudio)
            {
                AutoAddressableUtils.ExecuteWithActive(obj, (comp) => { comp.ProcessAudioData(); });
                countAudio++;
            }
        }
        }
}
#endif