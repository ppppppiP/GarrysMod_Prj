﻿using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class AutoAddressable : MonoBehaviour
{
    // Флаги для включения обработки разных типов ассетов
    public bool processMesh = true;
    public bool processAudio = true;
    public bool processTexture = true;

    // Данные для мешей
    [Header("Mesh Data (для автоматической загрузки)")]
    public string fbxPath;    // Путь к исходному FBX-файлу
    public string meshName;   // Имя меша (например, "M_Rock_05")
    public string meshAddress; // Вычисленный адрес, например "FBXName[MeshName]"

    public string GetMeshAddress()
    {
        if (!string.IsNullOrEmpty(meshAddress))
            return meshAddress;
        if (string.IsNullOrEmpty(fbxPath) || string.IsNullOrEmpty(meshName))
            return "";
        string baseName = Path.GetFileNameWithoutExtension(fbxPath);
        meshAddress = $"{baseName}[{meshName}]";



        return meshAddress;
    }
#if UNITY_EDITOR
    public void ProcessMeshData()
    {
        var mf = GetComponent<MeshFilter>();
        if (mf != null && mf.sharedMesh != null)
        {
            string assetPath = UnityEditor.AssetDatabase.GetAssetPath(mf.sharedMesh);
            if (!string.IsNullOrEmpty(assetPath))
            {
                fbxPath = assetPath;
            }
            meshName = mf.sharedMesh.name;
            
            GetMeshAddress();
            Debug.Log($"[AutoAddressable] Извлечены данные меша: {meshAddress}");
            mf.sharedMesh = null;

            EditorUtility.SetDirty(this);

        }
        else
        {
            Debug.LogWarning($"[AutoAddressable] MeshFilter или sharedMesh отсутствует на {gameObject.name}");
        }
    }
#endif
    // Данные для аудио
    [Header("Audio Data (для автоматической загрузки)")]
    public string audioPath;      // Путь к исходному аудиофайлу
    public string audioClipName;  // Имя аудиоклипа

    public string GetAudioAddress()
    {
        if (string.IsNullOrEmpty(audioPath) || string.IsNullOrEmpty(audioClipName))
            return "";
        // Например, используем имя файла без расширения
        string baseName = Path.GetFileNameWithoutExtension(audioPath);
        return $"{baseName}";
    }

    // Статический кэш для аудио данных, чтобы один и тот же аудиоклип не обрабатывался несколько раз
    public static Dictionary<int, (string audioPath, string audioClipName)> sharedAudioCache = new Dictionary<int, (string, string)>();
#if UNITY_EDITOR
    public void ProcessAudioData()
    {
        var audioSource = GetComponent<AudioSource>();
        if (audioSource != null && audioSource.clip != null)
        {
            int clipId = audioSource.clip.GetInstanceID();
            if (sharedAudioCache.ContainsKey(clipId))
            {
                (string cachedPath, string cachedName) = sharedAudioCache[clipId];
                audioPath = cachedPath;
                audioClipName = cachedName;
                Debug.Log($"[AutoAddressable] Используем кэшированные аудио данные для {gameObject.name}: {GetAudioAddress()}");
            }
            else
            {
                string assetPath = UnityEditor.AssetDatabase.GetAssetPath(audioSource.clip);
                if (!string.IsNullOrEmpty(assetPath))
                {
                    audioPath = assetPath;
                }
                audioClipName = audioSource.clip.name;
                sharedAudioCache[clipId] = (audioPath, audioClipName);
                
                Debug.Log($"[AutoAddressable] Извлечены аудио данные: {GetAudioAddress()} для {gameObject.name}");
            }
            // Очищаем аудиоклип для динамической загрузки

            EditorUtility.SetDirty(this);

            audioSource.clip = null;
        }
        else
        {
            Debug.LogWarning($"[AutoAddressable] AudioSource или clip отсутствует на {gameObject.name}");
        }
    }
#endif
    // Данные для текстур
    [Header("Texture Data (для автоматической загрузки)")]
    public string texturePath;    // Путь к исходной текстуре
    public string textureName;    // Имя текстуры
    public static Dictionary<int, (string texturePath, string textureName)> sharedTextureCache = new Dictionary<int, (string, string)>();


    public string GetTextureAddress()
    {
        if (string.IsNullOrEmpty(texturePath) || string.IsNullOrEmpty(textureName))
            return "";
        string baseName = Path.GetFileNameWithoutExtension(texturePath);
        return $"{baseName}";
    }

    // Кэш для текстур (как уже реализовано)
    
#if UNITY_EDITOR
    public void ProcessTextureData()
    {
        var renderer = GetComponent<Renderer>();
        if (renderer != null && renderer.sharedMaterial != null)
        {
            int matId = renderer.sharedMaterial.GetInstanceID();
            if (sharedTextureCache.ContainsKey(matId))
            {
                (string cachedPath, string cachedName) = sharedTextureCache[matId];
                texturePath = cachedPath;
                textureName = cachedName;
                Debug.Log($"[AutoAddressable] Используем кэшированную текстуру для {gameObject.name}: {GetTextureAddress()}");
            }
            else if (renderer.sharedMaterial.mainTexture != null)
            {
                string assetPath = UnityEditor.AssetDatabase.GetAssetPath(renderer.sharedMaterial.mainTexture);
                if (!string.IsNullOrEmpty(assetPath))
                {
                    texturePath = assetPath;
                    sharedTextureCache[matId] = (texturePath, renderer.sharedMaterial.mainTexture.name);
                }
                textureName = renderer.sharedMaterial.mainTexture.name;
                Debug.Log($"[AutoAddressable] Извлечены данные текстуры: {GetTextureAddress()} для {gameObject.name}");
                renderer.sharedMaterial.mainTexture = null;

                EditorUtility.SetDirty(this);

            }
            else
            {
                Debug.LogWarning($"[AutoAddressable] Material у {gameObject.name} уже очищен и не найден в кэше.");
            }
        }
        else
        {
            Debug.LogWarning($"[AutoAddressable] Renderer или материал отсутствует на {gameObject.name}");
        }
    }
#endif
    public void ClearAddressableAssets()
    {
        // Сброс меша
        var mf = GetComponent<MeshFilter>();
        if (mf != null)
        {
            mf.sharedMesh = null;
            Debug.Log($"[AutoAddressable] Меш очищен на {gameObject.name}");
        }
        // Сброс аудио
        var audioSource = GetComponent<AudioSource>();
        if (audioSource != null)
        {
            audioSource.clip = null;
            Debug.Log($"[AutoAddressable] Аудио очищено на {gameObject.name}");
        }
        // Сброс текстуры
        var rend = GetComponent<Renderer>();
        if (rend != null && rend.sharedMaterial != null)
        {
            rend.sharedMaterial.mainTexture = null;
            Debug.Log($"[AutoAddressable] Текстура очищена на {gameObject.name}");
        }
        // При этом можно, если нужно, оставить данные (audioPath, texturePath и т.д.) или сбросить их
    }
}