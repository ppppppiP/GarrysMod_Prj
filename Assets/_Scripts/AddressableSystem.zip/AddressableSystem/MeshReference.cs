﻿using System.IO;
using UnityEngine;

public class MeshReference : MonoBehaviour
{
    // Сохраняем путь к исходному FBX (например, "Assets/Models/Rock.fbx")
    public string fbxPath;
    // Сохраняем имя меша, как он указан в импорте (например, "M_Rock_05")
    public string meshName;

    // Формирует полный адрес для загрузки: "Rock[M_Rock_05]"
    public string GetFullAddress()
    {
        if (string.IsNullOrEmpty(fbxPath) || string.IsNullOrEmpty(meshName))
            return "";
        string baseName = Path.GetFileNameWithoutExtension(fbxPath);
        return $"{baseName}[{meshName}]";
    }
}