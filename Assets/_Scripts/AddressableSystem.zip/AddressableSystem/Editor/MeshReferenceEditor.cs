﻿#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(MeshReference))]
public class MeshReferenceEditor : Editor
{
    public override void OnInspectorGUI()
    {
        MeshReference mr = (MeshReference)target;

        // Отображаем текущие поля для контроля
        EditorGUILayout.LabelField("Текущий полный адрес:", mr.GetFullAddress());
        mr.fbxPath = EditorGUILayout.TextField("FBX Path", mr.fbxPath);
        mr.meshName = EditorGUILayout.TextField("Mesh Name", mr.meshName);

        if (GUILayout.Button("Захватить данные из MeshFilter и очистить его"))
        {
            MeshFilter mf = mr.GetComponent<MeshFilter>();
            if (mf != null && mf.sharedMesh != null)
            {
                // Получаем путь к мешу
                string assetPath = AssetDatabase.GetAssetPath(mf.sharedMesh);
                if (!string.IsNullOrEmpty(assetPath))
                {
                    mr.fbxPath = assetPath;
                }
                // Захватываем имя меша
                mr.meshName = mf.sharedMesh.name;

                // Выводим информацию в консоль
                Debug.Log($"Захвачено: {mr.GetFullAddress()}");

                // Удаляем меш из MeshFilter, чтобы при запуске игры он загружался динамически
                mf.sharedMesh = null;

                EditorUtility.SetDirty(mr);
            }
            else
            {
                Debug.LogWarning("MeshFilter или sharedMesh не найдены на объекте.");
            }
        }

        DrawDefaultInspector();
    }
}
#endif
